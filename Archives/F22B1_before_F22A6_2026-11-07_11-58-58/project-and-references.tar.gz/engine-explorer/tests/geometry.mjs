// CPU-only checks of the assembled meshes; no browser, renderer or image comparisons.
// Canvas drawing is stubbed because only geometry and transforms are being checked.
import assert from 'node:assert/strict';
import {mkdtemp, rm} from 'node:fs/promises';
import {tmpdir, homedir} from 'node:os';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const skill = process.env.SKILL_DIR || path.join(homedir(), '.claude/skills/teardown');
const {build} = await import(pathToFileURL(path.join(skill, 'node_modules/esbuild/lib/main.js')));
const scratch = await mkdtemp(path.join(tmpdir(), 'honda-geometry-'));
try {
  const output = path.join(scratch, 'geometry.cjs');
  await build({
    stdin: {contents: "export {buildEngine} from './src/engine.js'; export {beltTrack} from './src/detail-timing.js'; export * from './src/kin.js'; export * as THREE from 'three';", resolveDir: project},
    outfile: output, bundle: true, platform: 'node', format: 'cjs',
    nodePaths: [path.join(skill, 'node_modules')], logLevel: 'silent',
  });
  const ctx = new Proxy({createImageData: (w,h) => ({data: new Uint8ClampedArray(w*h*4)})}, {get: (o,k) => k in o ? o[k] : () => {}});
  globalThis.document = {createElement: tag => {
    assert.equal(tag, 'canvas');
    return {width: 0, height: 0, getContext: () => ctx};
  }};
  const {buildEngine, beltTrack, THREE, CYL, DECK, SPEC, TDC} = await import(pathToFileURL(output));
  const track=beltTrack([[0,0],[10,0],[10,10],[0,10]]);
  assert.equal(track.length,40);
  assert.deepEqual(track.sample(5),{x:5,y:0,tx:1,ty:0});
  assert.deepEqual(track.sample(-5),{x:0,y:5,tx:0,ty:-1});
  assert.deepEqual(track.sample(45),track.sample(5));
  const e = buildEngine();
  e.root.scale.setScalar(1); // All assertions below are in model millimetres.
  const meshes = [];
  e.root.traverse(m => {
    if (!m.isMesh) return;
    meshes.push(m);
    assert.ok(m.material && e.GHOST.has(m.userData.mat0), `Unregistered material on ${m.userData.part}`);
    for (const key of ['position', 'normal']) {
      const attribute = m.geometry.getAttribute(key);
      if (attribute) assert.ok(attribute.array.every(Number.isFinite), `Non-finite ${key}: ${m.userData.part}`);
    }
  });
  for (const id of Object.keys(e.G)) {
    // Synchronising pins inherit their moving rocker transforms, so their
    // geometry is tagged by part id rather than parented under the index group.
    assert.ok(meshes.some(m=>m.userData.part===id), `Empty selectable part: ${id}`);
  }
  const pose = (th,vtec=0) => {e.update(th, {dt:0, vtec, locked:Array(4).fill(vtec)});e.root.updateMatrixWorld(true);};
  pose(0);
  const beltTeeth=meshes.filter(m=>m.isInstancedMesh&&m.userData.crankDriven);
  assert.equal(beltTeeth.length,2,'Both internal belts need crank-driven transverse teeth');
  const teethAtZero=beltTeeth.map(m=>Array.from(m.instanceMatrix.array));
  pose(25);
  beltTeeth.forEach((m,i)=>{
    assert.ok(m.instanceMatrix.array.every(Number.isFinite),'Invalid tooth transform');
    assert.notDeepEqual(Array.from(m.instanceMatrix.array),teethAtZero[i],'Belt teeth did not travel with crank angle');
    assert.ok(Number.isFinite(m.boundingSphere.radius)&&m.boundingSphere.radius>0,'Invalid tooth bounds');
  });
  pose(0);
  beltTeeth.forEach((m,i)=>assert.deepEqual(Array.from(m.instanceMatrix.array),teethAtZero[i],'Seeking did not restore belt tooth phase'));
  const down = new THREE.Vector3(0,-1,0);
  const ray = new THREE.Raycaster();
  const castDown = (x,y,z,objects,far) => {
    ray.set(new THREE.Vector3(x,y,z),down);ray.near=0;ray.far=far;
    return ray.intersectObjects(objects,true);
  };
  for (const c of CYL) {
    // Sampling centre and near-wall radii catches filled blocks, accidental lids,
    // or a liner axis rotated away from the cylinder axis.
    for (const x of [0,-40,40]) {
      assert.equal(castDown(x,DECK+0.3,c.z,[e.G.block],128).length,0,`Blocked bore ${c.c} at x=${x}`);
      assert.equal(castDown(x,DECK+3,c.z,[e.G.headGasket],4).length,0,`Blocked gasket aperture ${c.c}`);
    }
  }
  for (const pin of e.G.wristPins.children) {
    const box = new THREE.Box3().setFromObject(pin), size = box.getSize(new THREE.Vector3());
    assert.ok(Math.abs(size.x-SPEC.wristPinDia)<0.3 && Math.abs(size.y-SPEC.wristPinDia)<0.3, 'Pin diameter/axis mismatch');
    assert.ok(size.z>size.x*3, 'Wrist pin is not parallel to crankshaft');
  }
  const pistonGroups = e.G.pistons.children.filter(g=>g.isGroup);
  const vertex = new THREE.Vector3();
  let closest = Infinity;
  for (const vtec of [0,1]) for (const c of CYL) for (const offset of [0,360]) {
    pose(TDC[c.c]+offset,vtec);
    const piston = pistonGroups[c.i];
    const pistonBox = new THREE.Box3().setFromObject(piston);
    assert.ok(pistonBox.max.y <= DECK-0.49, `Piston ${c.c} projects through deck`);
    for (const id of ['intakeValves','exhaustValves']) {
      for (const g of e.G[id].children) {
        if (!g.isGroup || Math.abs(g.position.z-c.z)>25) continue;
        const face=g.children.find(m=>m.geometry?.type==='LatheGeometry');
        if (!face) continue;
        const positions=face.geometry.attributes.position;
        for(let k=0;k<positions.count;k++) {
          vertex.fromBufferAttribute(positions,k).applyMatrix4(face.matrixWorld);
          if(Math.hypot(vertex.x,vertex.z-c.z)>SPEC.bore/2-1)continue;
          const hits=castDown(vertex.x,DECK+30,vertex.z,[piston],100);
          if(!hits.length)continue;
          const clearance=vertex.y-hits[0].point.y;
          closest=Math.min(closest,clearance);
          assert.ok(clearance>0, `${id} penetrates piston ${c.c} at ${offset?'overlap':'compression'} TDC, VTEC ${vtec}, by ${(-clearance).toFixed(2)} mm`);
        }
      }
    }
  }
  for(const th of [0,90,180,270,360,450,540,630,720]) {
    pose(th);
    for(const m of meshes) assert.ok(m.matrixWorld.elements.every(Number.isFinite),`Non-finite transform: ${m.userData.part}`);
  }
  console.log(`Geometry checks passed: ${meshes.length} meshes; 4 open bores; pins parallel to crank; minimum sampled TDC valve/piston clearance ${closest.toFixed(2)} mm (illustrative geometry).`);
} finally {
  delete globalThis.document;
  await rm(scratch,{recursive:true,force:true});
}
