import {CATALOG, CATALOG_SYSTEMS} from './catalog.js';
import SCENES from './scenes.json';
import {mountPbrFigure} from './pbr-runtime.js';

const mediaRevision=typeof __ANATOMY_MEDIA_REVISION__==='string'?__ANATOMY_MEDIA_REVISION__:'development';
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const normal = value => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const systems = Object.fromEntries(CATALOG_SYSTEMS.map(s=>[s.id,s.label]));
const views = {exterior:'exterior',bottom:'lower',balance:'lower',head:'noCover',vtec:'vtec',timing:'noTiming',intake:'exterior',exhaust:'exterior',ignition:'noCover',oil:'lower',cooling:'noTiming',accessory:'exterior'};
const motionNames = {fixed:'Permanece fija',rotate:'Giro',reciprocate:'Movimiento alternativo',rock:'Oscilación',spring:'Compresión elástica',flow:'Paso de fluido',switch:'Accionamiento'};
const saved = (key,fallback) => { try { return JSON.parse(localStorage.getItem('f22.anatomy.'+key)) ?? fallback; } catch { return fallback; } };
const remember = (key,value) => { try { localStorage.setItem('f22.anatomy.'+key,JSON.stringify(value)); } catch {} };

export function runAnatomy() {
  document.documentElement.lang='es';
  document.title='Anatomía del Honda F22 · Piezas individuales';
  const root=document.getElementById('app');
  const requested=new URLSearchParams(location.search).get('piece');
  const S={entry:CATALOG.find(x=>x.id===requested)||CATALOG.find(x=>x.id==='piston')||CATALOG[0],query:'',system:'',mode:'3d',info:'function',phase:0,angle:0,tilt:0,zoom:1,demonstrating:false,playing:false,speed:1,theme:saved('theme','light'),large:saved('large',false)};
  root.innerHTML=`
    <a class="skip" href="#catalog-search">Buscar una pieza</a>
    <header class="atlas-header">
      <div class="atlas-brand"><a href="index.html" class="back-engine">← Motor completo</a><div><h1>Anatomía del F22</h1><p>Piezas individuales · Honda Accord 1994–97</p></div></div>
      <div class="header-actions"><button id="large-text" aria-label="Texto grande" aria-pressed="false">Aa <span>Texto grande</span></button><button id="theme-toggle">Contraste oscuro</button></div>
    </header>
    <main class="atlas-layout">
      <aside class="catalog" aria-label="Catálogo de piezas">
        <div class="catalog-heading"><h2>Explorar piezas</h2><span class="total-count">${CATALOG.length}</span></div>
        <label class="sr" for="catalog-search">Buscar piezas</label><input id="catalog-search" type="search" placeholder="Pistón, resorte, tornillo…" autocomplete="off">
        <label class="sr" for="catalog-system">Sistema del motor</label><select id="catalog-system"><option value="">Todos los sistemas</option>${CATALOG_SYSTEMS.map(s=>`<option value="${esc(s.id)}">${esc(s.label)}</option>`).join('')}</select>
        <p id="results-count" class="results-count" aria-live="polite"></p>
        <div id="catalog-list"></div>
        <p class="catalog-foot">Cada ficha representa un tipo de pieza. Las cantidades indican sus repeticiones en el motor.</p>
      </aside>
      <section class="workspace" aria-labelledby="piece-title">
        <header class="piece-header"><div><p id="piece-system" class="eyebrow"></p><h2 id="piece-title" tabindex="-1"></h2><p id="piece-english" class="secondary-name"></p></div><div class="piece-navigation"><button id="previous-piece" aria-label="Pieza anterior">←</button><span id="piece-index"></span><button id="next-piece" aria-label="Pieza siguiente">→</button></div></header>
        <div class="piece-workbench">
          <section class="visual-column" aria-label="Representación de la pieza">
            <div class="visual-tabs" role="tablist" aria-label="Ver la pieza"><button id="mode-3d" role="tab" aria-selected="true" aria-controls="model-panel" tabindex="0">Modelo 3D</button><button id="mode-video" role="tab" aria-selected="false" aria-controls="video-panel" tabindex="-1">Video explicado</button></div>
            <div id="model-panel" role="tabpanel" aria-labelledby="mode-3d">
              <div class="mechanism-controls"><button id="play-mechanism" class="primary">▶ Ver movimiento</button><label class="speed-label">Velocidad<select id="mechanism-speed"><option value="0.5">Lenta</option><option value="1" selected>Normal</option></select></label><button id="step-mechanism" aria-label="Avanzar un paso del mecanismo">Paso →</button></div>
              <div class="figure-plate" id="figure-plate"><div class="figure-caption"><span id="figure-number"></span><span id="motion-badge"></span></div><div id="figure-stage" class="pbr-stage" role="group" tabindex="0" aria-label="Modelo tridimensional. Arrastra para girar e inclinar. Usa las flechas para cambiar la vista; más y menos para ampliar."></div><div class="figure-foot"><div class="inspection-controls"><button id="rotate-left" aria-label="Girar vista a la izquierda">↶</button><button id="rotate-right" aria-label="Girar vista a la derecha">↷</button><span class="control-separator"></span><button id="zoom-out" aria-label="Alejar pieza">−</button><button id="zoom-in" aria-label="Acercar pieza">+</button><button id="reset-piece">Restablecer vista</button></div><span id="angle-readout">Vista 0°</span></div></div>
              <label class="phase-control"><span>Recorrido de la demostración</span><input id="phase-slider" type="range" min="0" max="1000" value="0" aria-label="Recorrido de la demostración"><output id="phase-output">0%</output></label>
              <p class="motion-caption" id="motion-caption"></p>
            </div>
            <div id="video-panel" role="tabpanel" aria-labelledby="mode-video" hidden><video id="piece-video" controls playsinline preload="none" aria-label="Video explicativo de la pieza"></video><p class="video-description">Video con textos en español. Para oír la explicación, usa Escuchar. Puedes pausar, ampliar o descargar el video.</p><a id="download-video" class="button-link" download>↓ Descargar MP4</a><p id="video-error" class="notice" hidden>El video no está disponible en esta copia. Conserva la carpeta anatomy-media junto a esta página.</p></div>
            <div class="representation-note"><span aria-hidden="true">≈</span><p>Representación didáctica basada en las referencias disponibles. Las formas pequeñas y los recorridos sin medida documentada son aproximados.</p></div>
          </section>
          <aside class="piece-explanation" aria-label="Explicación de la pieza">
            <div class="piece-meta"><span id="quantity-tag"></span><button id="read-piece" aria-pressed="false">Escuchar</button></div>
            <div class="info-tabs" role="tablist" aria-label="Información de la pieza"><button id="info-function" role="tab" data-info="function" aria-selected="true" aria-controls="info-content" tabindex="0">Función</button><button id="info-motion" role="tab" data-info="motion" aria-selected="false" aria-controls="info-content" tabindex="-1">Movimiento</button><button id="info-reference" role="tab" data-info="reference" aria-selected="false" aria-controls="info-content" tabindex="-1">Referencia</button></div>
            <section id="info-content" role="tabpanel" aria-labelledby="info-function"></section>
            <a id="locate-piece" class="locate-link">Ubicar su conjunto en el motor <span aria-hidden="true">↗</span></a>
          </aside>
        </div>
        <footer class="atlas-footer"><span>Anatomy · Piezas y mecanismos del F22</span><span>Referencia provisional: F22B1 SOHC VTEC</span></footer>
      </section>
    </main><div class="sr" id="announcement" aria-live="polite"></div>`;
  const $=q=>root.querySelector(q), $$=q=>[...root.querySelectorAll(q)];
  let figure=null,raf=0,last=0,drag=null,speaking=false;
  const announce=text=>{$('#announcement').textContent=text;};
  const matches=()=>CATALOG.filter(e=>(!S.system||e.system===S.system)&&normal([e.label,e.english,e.function,...(e.oem||[]).map(o=>o.pn)].join(' ')).includes(normal(S.query)));
  const applyTheme=()=>{document.documentElement.dataset.theme=S.theme;document.documentElement.classList.toggle('large-text',S.large);$('#figure-plate').dataset.theme=S.theme;$('#theme-toggle').textContent=S.theme==='light'?'Contraste oscuro':'Contraste claro';$('#large-text').setAttribute('aria-pressed',String(S.large));remember('theme',S.theme);remember('large',S.large);};
  function renderList(){
    const entries=matches();
    $('#results-count').textContent=`${entries.length} ${entries.length===1?'pieza':'piezas'}`;
    const grouped=CATALOG_SYSTEMS.map(s=>({...s,entries:entries.filter(e=>e.system===s.id)})).filter(s=>s.entries.length);
    $('#catalog-list').innerHTML=grouped.length?grouped.map(s=>`<details class="system-group" ${S.query||S.system||s.id===S.entry.system?'open':''}><summary>${esc(s.label)}<span>${s.entries.length}</span></summary><ul>${s.entries.map(e=>`<li><button data-piece="${esc(e.id)}" ${e.id===S.entry.id?'aria-current="true"':''}><span>${esc(e.label)}</span><span class="row-arrow" aria-hidden="true">↗</span></button></li>`).join('')}</ul></details>`).join(''):`<div class="no-results"><p>No hay coincidencias.</p><button id="clear-search">Mostrar todas las piezas</button></div>`;
    $('#clear-search')?.addEventListener('click',()=>{S.query='';S.system='';$('#catalog-search').value='';$('#catalog-system').value='';renderList();});
  }
  function renderInfo(){
    const e=S.entry;
    $$('[data-info]').forEach(b=>{const active=b.dataset.info===S.info;b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;});
    $('#info-content').setAttribute('aria-labelledby','info-'+S.info);
    if(S.info==='function') $('#info-content').innerHTML=`<h3>Qué hace</h3><p class="lead-description">${esc(e.function)}</p><h3>Dónde está</h3><p>${esc(e.location)}</p><h3>Con qué trabaja</h3><p>${esc(e.connections)}</p>`;
    else if(S.info==='motion') $('#info-content').innerHTML=`<h3>${esc(motionNames[e.motion.type]||'Cómo funciona')}</h3><p class="lead-description">${esc(e.motion.description)}</p><h3>Qué lo acciona</h3><p>${esc(e.motion.driver)}</p><h3>Paso a paso</h3><ol class="explanation-steps">${e.steps.map((s,i)=>`<li><span>${i+1}</span><p>${esc(s)}</p></li>`).join('')}</ol>`;
    else $('#info-content').innerHTML=`<h3>Referencia de la pieza</h3><p>${esc(e.note||'Forma reconstruida para explicar su función. No es un plano de fabricación.')}</p>${e.oem.length?`<ul class="oem-list">${e.oem.map(o=>`<li><a href="../Honda Reference Library/02_OEM_Diagrams/${esc(o.diagram)}.png" target="_blank" rel="noopener">Abrir diagrama · llamada ${esc(o.callout)}</a><p>${esc(o.pn)}</p></li>`).join('')}</ul>`:'<p>Esta pieza se muestra como detalle del conjunto. No se ha confirmado una referencia OEM independiente.</p>'}<p class="reference-note">La identificación F22B1 es provisional. Algunas referencias corresponden a conjuntos de servicio o variantes del catálogo.</p>`;
  }
  function draw(){
    figure?.update({angle:S.angle,tilt:S.tilt,zoom:S.zoom,theme:S.theme,inspection:!S.demonstrating,phase:S.phase,entry:S.entry});
    $('#figure-stage').style.setProperty('--figure-zoom',S.zoom);
    $('#angle-readout').textContent=`Vista ${Math.round(((S.angle%360)+360)%360)}°`;
    $('#phase-slider').value=Math.round(S.phase*1000);
    $('#phase-output').textContent=`${Math.round(S.phase*100)}%`;
  }
  function stop(){S.playing=false;cancelAnimationFrame(raf);raf=0;$('#play-mechanism').textContent='▶ Ver movimiento';}
  function tick(now){
    if(!S.playing||S.mode!=='3d'||document.hidden){raf=0;return;}
    const dt=Math.min((now-last)/1000,1/30);last=now;
    S.phase=(S.phase+dt*S.speed/8)%1;draw();raf=requestAnimationFrame(tick);
  }
  function play(){
    if(S.playing){stop();return;}
    S.demonstrating=true;S.playing=true;$('#play-mechanism').textContent='❚❚ Pausar';last=performance.now();raf=requestAnimationFrame(tick);
  }
  function setMode(mode,focus=false){
    S.mode=mode;stop();$('#piece-video').pause();
    for(const id of ['3d','video']){const on=id===mode;$('#mode-'+id).setAttribute('aria-selected',String(on));$('#mode-'+id).tabIndex=on?0:-1;$('#'+(id==='3d'?'model':'video')+'-panel').hidden=!on;}
    if(focus)$('#mode-'+mode).focus();
  }
  function stopSpeech(){if('speechSynthesis'in window)speechSynthesis.cancel();speaking=false;$('#read-piece').textContent='Escuchar';$('#read-piece').setAttribute('aria-pressed','false');}
  function choose(entry,focus=false){
    if(!entry)return;
    stop();stopSpeech();figure?.destroy();S.entry=entry;S.phase=0;S.angle=0;S.tilt=0;S.zoom=1;S.demonstrating=false;
    $('#piece-system').textContent=systems[entry.system]||entry.system;$('#piece-title').textContent=entry.label;$('#piece-english').textContent=entry.english;
    const index=CATALOG.indexOf(entry)+1;$('#piece-index').textContent=`${index} / ${CATALOG.length}`;$('#figure-number').textContent=`FIG. ${String(index).padStart(2,'0')}`;
    $('#motion-badge').textContent=motionNames[entry.motion.type]||'Demostración';$('#quantity-tag').textContent=entry.quantity;
    const fixed=entry.motion.type==='fixed';
    $('#play-mechanism').disabled=fixed;$('#step-mechanism').disabled=fixed;$('#mechanism-speed').disabled=fixed;$('#phase-slider').disabled=fixed;
    $('.mechanism-controls').hidden=fixed;$('.phase-control').hidden=fixed;
    $('#motion-caption').textContent=fixed?'Esta pieza permanece fija durante el funcionamiento. Girar la vista permite inspeccionarla.':entry.motion.description;
    if(['pump-oil','pump-water','pump-power-steering'].includes(entry.id)) $('#motion-caption').textContent+=' La sección muestra el giro interno; no calcula presión ni caudal.';
    $('#figure-stage').innerHTML='';
    const sceneRef=SCENES[entry.id]||SCENES[entry.kind];
    const scene=typeof sceneRef==='string'?SCENES[sceneRef]:sceneRef;
    if(scene){figure=mountPbrFigure($('#figure-stage'),scene,entry);draw();}else{figure=null;$('#figure-stage').innerHTML='<p class="figure-error">La representación de esta pieza no se pudo cargar.</p>';}
    const video=$('#piece-video');video.pause();video.src=`anatomy-media/${entry.id}.mp4?v=${mediaRevision}`;video.poster=`anatomy-media/${entry.id}.jpg?v=${mediaRevision}`;video.setAttribute('aria-label',`Video: ${entry.label}`);
    video.innerHTML=`<track kind="captions" src="anatomy-media/${esc(entry.id)}.vtt?v=${mediaRevision}" srclang="es" label="Español">`;
    $('#download-video').href=video.src;$('#download-video').download=`honda-f22-${entry.id}.mp4`;$('#video-error').hidden=true;
    $('#locate-piece').href=`index.html?part=${encodeURIComponent(entry.parentId)}&view=${encodeURIComponent(views[entry.system]||'exterior')}`;
    renderList();renderInfo();
    try{history.replaceState(null,'',`?piece=${encodeURIComponent(entry.id)}`);}catch{}
    announce(`Pieza seleccionada: ${entry.label}. ${entry.quantity}.`);
    if(focus)$('#piece-title').focus({preventScroll:true});
  }
  function stepEntry(direction){const visible=matches(),list=visible.length?visible:CATALOG;let index=list.findIndex(e=>e.id===S.entry.id);if(index<0)index=direction>0?-1:0;choose(list[(index+direction+list.length)%list.length],true);}
  $('#catalog-search').addEventListener('input',e=>{S.query=e.target.value;renderList();});
  $('#catalog-system').addEventListener('change',e=>{S.system=e.target.value;renderList();});
  $('#catalog-list').addEventListener('click',e=>{const b=e.target.closest('[data-piece]');if(b)choose(CATALOG.find(x=>x.id===b.dataset.piece),true);});
  $('#previous-piece').onclick=()=>stepEntry(-1);$('#next-piece').onclick=()=>stepEntry(1);
  $('#theme-toggle').onclick=()=>{S.theme=S.theme==='light'?'dark':'light';applyTheme();draw();};
  $('#large-text').onclick=()=>{S.large=!S.large;applyTheme();draw();};
  for(const mode of ['3d','video'])$('#mode-'+mode).onclick=()=>setMode(mode);
  $('.visual-tabs').addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();setMode(e.key==='Home'?'3d':e.key==='End'?'video':S.mode==='3d'?'video':'3d',true);}});
  $$('[data-info]').forEach(b=>b.onclick=()=>{S.info=b.dataset.info;renderInfo();});
  $('.info-tabs').addEventListener('keydown',e=>{const ids=['function','motion','reference'];if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();S.info=ids[e.key==='Home'?0:e.key==='End'?2:(ids.indexOf(S.info)+(e.key==='ArrowLeft'?2:1))%3];renderInfo();$('#info-'+S.info).focus();});
  $('#rotate-left').onclick=()=>{S.angle-=15;draw();};$('#rotate-right').onclick=()=>{S.angle+=15;draw();};
  const zoom=d=>{S.zoom=Math.max(.7,Math.min(4,S.zoom*d));draw();};
  $('#zoom-in').onclick=()=>zoom(1.15);$('#zoom-out').onclick=()=>zoom(1/1.15);
  $('#reset-piece').onclick=()=>{stop();S.demonstrating=false;S.angle=0;S.tilt=0;S.zoom=1;draw();};
  $('#play-mechanism').onclick=play;
  $('#mechanism-speed').onchange=e=>{S.speed=Number(e.target.value);};
  $('#step-mechanism').onclick=()=>{stop();S.demonstrating=true;S.phase=(S.phase+1/24)%1;draw();};
  $('#phase-slider').oninput=e=>{stop();S.demonstrating=true;S.phase=Number(e.target.value)/1000;draw();};
  const stage=$('#figure-stage');
  stage.addEventListener('pointerdown',e=>{if(e.button!==0)return;drag={x:e.clientX,y:e.clientY,angle:S.angle,tilt:S.tilt};stage.setPointerCapture(e.pointerId);});
  stage.addEventListener('pointermove',e=>{if(!drag)return;S.angle=drag.angle+(e.clientX-drag.x)*.55;S.tilt=Math.max(-103,Math.min(57,drag.tilt+(e.clientY-drag.y)*.4));draw();});
  stage.addEventListener('pointerup',()=>{drag=null;});stage.addEventListener('pointercancel',()=>{drag=null;});
  stage.addEventListener('keydown',e=>{if(e.key==='ArrowLeft')S.angle-=e.shiftKey?30:10;else if(e.key==='ArrowRight')S.angle+=e.shiftKey?30:10;else if(e.key==='ArrowUp')S.tilt=Math.min(57,S.tilt+10);else if(e.key==='ArrowDown')S.tilt=Math.max(-103,S.tilt-10);else if(e.key==='+'||e.key==='='){e.preventDefault();zoom(1.15);return;}else if(e.key==='-'){e.preventDefault();zoom(1/1.15);return;}else if(e.key==='Home'){stop();S.demonstrating=false;S.angle=0;S.tilt=0;S.zoom=1;}else if(e.key===' '&&!$('#play-mechanism').disabled){e.preventDefault();play();return;}else return;e.preventDefault();draw();});
  $('#piece-video').addEventListener('error',()=>{$('#video-error').hidden=false;});
  $('#read-piece').onclick=()=>{
    if(!('speechSynthesis'in window)){announce('La lectura en voz alta no está disponible en este navegador.');return;}
    if(speaking){stopSpeech();return;}
    const e=S.entry,u=new SpeechSynthesisUtterance(`${e.label}. ${e.function} Ubicación. ${e.location} Conexiones. ${e.connections} Movimiento. ${e.motion.description} ${e.steps.join(' ')}`);
    u.lang='es';u.rate=.85;const voice=speechSynthesis.getVoices().find(v=>v.lang.startsWith('es'));if(voice)u.voice=voice;
    speaking=true;$('#read-piece').textContent='Detener lectura';$('#read-piece').setAttribute('aria-pressed','true');u.onend=u.onerror=stopSpeech;speechSynthesis.speak(u);
  };
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf);raf=0;$('#piece-video').pause();}else if(S.playing&&!raf){last=performance.now();raf=requestAnimationFrame(tick);}});
  addEventListener('pagehide',()=>{stop();stopSpeech();figure?.destroy();});
  applyTheme();choose(S.entry);
}
