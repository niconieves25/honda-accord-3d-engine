import { TURN } from './vendor/turn.mjs';
const TAU=Math.PI*2;
const aliases={ring:'compressionRing',oilring:'oilRing',camshaft:'shaft',oilPump:'pump',waterPump:'pump',psPump:'pump',hose:'pipe',lead:'pipe',intakerunner:'manifold',sparkplug:'sparkPlug',toothedpulley:'pulley'};
const E=[1,0,0,0,1,0,0,0,1];
export function figureValues(rawKind,{phase=0,angle=0,entry}={}){
 const kind=aliases[rawKind]||rawKind,p=((phase%1)+1)%1,t=p*TAU*2;
 let work={R:[...E],t:[0,0,0]},rotor={R:[...E],t:[0,0,0]},idler={R:[...E],t:[0,0,0]};
 const spin=(axis,deg)=>({R:TURN.rotation(axis,deg),t:[0,0,0]});
 if(entry?.motion?.type==='fixed')return {orbit:angle,work,rotor,idler};
 const lift=Math.max(0,Math.sin(p*TAU));
 if(['piston','compressionRing','oilRing','pin'].includes(kind)){const r=47.5,l=142;const travel=r*(1-Math.cos(t))+l-Math.sqrt(l*l-r*r*Math.sin(t)**2);work.t=[0,0,-travel+47.5];}
 if(kind==='rod'||kind==='rodCap'||entry?.id==='bearing-rod'||entry?.id==='bolt-connecting-rod'){
   const r=47.5,l=142,beta=Math.asin(r/l*Math.sin(t));const R=TURN.rotation([0,1,0],beta*180/Math.PI),z0=kind==='rod'?-60:0;
   work={R,t:[-r*Math.sin(t)-R[2]*z0,0,z0+r*Math.cos(t)-R[8]*z0]};
 }
 if(['crankshaft','pulley','groovedPulley','belt'].includes(kind))work=spin([0,1,0],p*(entry?.id==='pulley-camshaft'?-360:kind==='crankshaft'||entry?.id==='pulley-crank-timing'?-720:720));
 if(kind==='shaft')work=spin([0,1,0],-p*360);
 if(kind==='balanceShaft'||entry?.id?.startsWith('shaft-balance'))work=spin([0,1,0],p*1440*(entry?.id==='shaft-balance-rear'?-1:1));
 if(kind==='plainShaft')work={R:[...E],t:[0,0,0]};
 if(kind==='valve'||kind==='retainer'||kind==='keeper')work.t=[0,0,-9*lift];
 if(kind==='spring')work={R:[1,0,0,0,1,0,0,0,1-.22*lift],t:[0,0,0]};
 if(kind==='rocker'||entry?.id==='screw-valve-lash')work=spin([0,1,0],14*lift);
 if(['pump','alternator','oilRotorPump','vanePump'].includes(kind))rotor=spin([0,1,0],p*720);
 if(kind==='oilRotorPump')idler=spin([0,1,0],p*720*6/7);
 if(kind==='alternatorRotor')work=spin([0,1,0],p*720);
 if(kind==='distributor')rotor=spin([0,0,1],p*360);
 if(kind==='distributorRotor'||entry?.id==='rotor-distributor')work=spin([0,0,1],p*360);
 if(kind==='throttle')rotor=spin([1,0,0],75*lift);
 if(kind==='injector'||kind==='solenoid'||kind==='diaphragm')rotor.t=[0,0,3*lift];
 if(kind==='plunger'||kind==='vtecPlate'||entry?.id==='plate-vtec-timing')work.t=[0,0,8*lift];
 if(kind==='thermostat')rotor.t=[0,0,8*lift];
 return {orbit:angle,work,rotor,idler};
}
