import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import * as THREE from 'three';

/** Photo/OEM-led exterior pass. Dimensions below are visual estimates, NOT Honda machining dimensions.
 * Evidence: photos 1/5/7/8/9; intake_manifold, throttle_body, exhaust_manifold, alternator_denso,
 * distributor_hitachi, p_s_pump_bracket and install_pipe_tubing diagrams in the reference library.
 * Runs once, after base geometry, before the material/selection registry is built.
 */
export function detailExterior({G, M, add, at, tube, cylZ, cylX, bolt, L, CYL, DECK}) {
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  const TAU = Math.PI * 2;
  const mark=(mesh,id,instance=0)=>{mesh.userData.catalogPiece=id;mesh.userData.catalogInstance=instance;mesh.name=`${id}:${instance}`;return mesh;};
  const curve = (pts) => new THREE.CatmullRomCurve3(pts.map(p => V(...p)), false, 'centripetal');
  const box = (id, size, pos, material = M.cast, radius = 3, parent) => at(add(id, new RoundedBoxGeometry(...size, 2, radius), material, parent), ...pos);
  const clear = id => {
    for (const child of [...G[id].children]) {
      G[id].remove(child);
      child.traverse(m => m.geometry?.dispose());
    }
  };
  const ring = (id, r, thickness, pos, normal = [0, 0, 1], mat = M.steel, parent) => {
    const mesh = at(add(id, new THREE.TorusGeometry(r, thickness, 6, 32), mat, parent), ...pos);
    mesh.quaternion.setFromUnitVectors(V(0, 0, 1), V(...normal).normalize());
    return mesh;
  };
  const annulus = (id, outer, inner, depth, pos, normal = [0, 0, 1], mat = M.cast, parent) => {
    const shape = new THREE.Shape();
    shape.absarc(0, 0, outer, 0, TAU, false);
    const hole = new THREE.Path();
    hole.absarc(0, 0, inner, 0, TAU, true);
    shape.holes.push(hole);
    const geo = new THREE.ExtrudeGeometry(shape, {depth, bevelEnabled: false, curveSegments: 24});
    geo.translate(0, 0, -depth / 2);
    const mesh = at(add(id, geo, mat, parent), ...pos);
    mesh.quaternion.setFromUnitVectors(V(0, 0, 1), V(...normal).normalize());
    return mesh;
  };
  const washer = (id, pos, normal = [1, 0, 0], r = 8) => annulus(id, r, r * 0.45, 1.4, pos, normal, M.darkSteel);
  const innerRubber = M.rubber.clone();
  innerRubber.side = THREE.BackSide;
  const innerCast = M.cast.clone();
  innerCast.side = THREE.BackSide;
  const hollowTube = (id, pts, radius, wall, mat, seg = 36) => {
    const c = curve(pts);
    add(id, new THREE.TubeGeometry(c, seg, radius, 20, false), mat);
    add(id, new THREE.TubeGeometry(c, seg, radius - wall, 20, false), mat === M.rubber || mat === M.plasticPlain ? innerRubber : innerCast);
    for (const end of [0, 1]) {
      const p = c.getPointAt(end), n = c.getTangentAt(end);
      annulus(id, radius, radius - wall, 0.8, p.toArray(), n.toArray(), mat);
    }
    return c;
  };
  const clamp = (id, pos, normal, radius) => {
    const n = V(...normal).normalize();
    annulus(id, radius + 1.7, radius + 0.3, 6, pos, normal, M.steel);
    const axis = Math.abs(n.y) < 0.85 ? V(0, 1, 0) : V(1, 0, 0);
    const t = new THREE.Vector3().crossVectors(n, axis).normalize();
    const p = V(...pos).addScaledVector(t, radius + 3);
    const screw = box(id, [10, 6, 6], p.toArray(), M.darkSteel, 1);
    screw.quaternion.setFromUnitVectors(V(1, 0, 0), n);
  };
  const connector = (id, pos, size = [14, 16, 19], color = M.plasticPlain) => {
    box(id, size, pos, color, 2);
    box(id, [size[0] + 2, 3, size[2] * 0.55], [pos[0], pos[1] + size[1] / 2, pos[2]], M.plasticPlain, 1);
    for (const dz of [-4, 0, 4]) tube(id, [[pos[0], pos[1] - size[1] / 2, pos[2] + dz], [pos[0] - 5, pos[1] - 17, pos[2] + dz]], 1.2, M.rubber, null, 4, 6);
  };

  // ---------------------------------------------------------- two-piece intake casting
  // Honda drawing: upper chamber 13 sits above gasket 14 and runner casting 11. The lower flange
  // follows four individual ports; it is not a flat lid laid across the top of the chamber.
  clear('plenum');
  clear('runners');
  const PX = 220, PY = DECK + 48, seamY = PY - 34;
  box('plenum', [84, 86, 414], [PX, PY + 3, -44], M.cast, 16);
  box('plenum', [90, 5, 416], [PX, seamY, -44], M.castLight, 2);
  box('plenum', [88, 1.5, 414], [PX, seamY - 3.2, -44], M.gasket, 1);
  for (const z of [-220, -146, -72, 2, 76, 144]) {
    // Circular casting witness marks along the upper surface, visible in photos 2 and 9.
    at(add('plenum', new THREE.CylinderGeometry(7.5, 7.5, 0.7, 20), M.castLight), PX, PY + 46.1, z);
  }
  for (const z of [-238, -150, -53, 43, 139]) {
    box('plenum', [25, 13, 22], [PX + 38, seamY + 3, z], M.cast, 5);
    bolt('plenum', PX + 42, seamY + 12, z, 'y', 5.3);
    // External ribs join flange lugs to the chamber wall.
    box('plenum', [8, 40, 8], [PX + 40, seamY + 23, z], M.cast, 2);
  }
  // Vacuum take-offs and the front blanking plug: open nipples, retaining beads and hex shoulders.
  hollowTube('plenum', [[PX + 40, PY + 20, -120], [PX + 59, PY + 30, -120]], 7, 2, M.castLight, 8);
  ring('plenum', 7.5, 1.1, [PX + 57, PY + 29, -120], [1, 0.5, 0], M.brass);
  hollowTube('plenum', [[PX + 40, PY + 17, 74], [PX + 63, PY + 26, 74]], 8, 2.5, M.castLight, 8);
  bolt('plenum', PX + 50, seamY + 7, 28, 'x', 10, M.brass);
  // A removable auxiliary air valve/connector on the side, as shown on throttle-body diagram ref19.
  at(add('plenum', cylZ(12, 58, 24), M.castLight), PX + 46, PY + 21, -203);
  connector('plenum', [PX + 58, PY + 13, -181], [17, 24, 20], M.gasket);
  tube('plenum', [[PX + 46, PY + 10, -230], [PX + 58, PY - 34, -226], [180, DECK - 22, -228]], 5, M.rubber, null, 24, 10);

  for (const cy of CYL) {
    const pts = [[120, DECK + 50, cy.z], [161, DECK + 29, cy.z], [192, DECK - 26, cy.z], [230, DECK - 39, cy.z * 0.98], [252, DECK - 9, cy.z * 0.96], [235, seamY - 4, cy.z * 0.94]];
    const c = curve(pts), frames = c.computeFrenetFrames(40, false);
    const positions = [], indices = [];
    for (let i = 0; i <= 40; i++) {
      const u = i / 40, p = c.getPointAt(u);
      const radius = 21 + 9 * Math.sin(Math.PI * u) ** 2;
      for (let j = 0; j <= 20; j++) {
        const a = j / 20 * TAU;
        const q = p.clone().addScaledVector(frames.normals[i], radius * Math.cos(a)).addScaledVector(frames.binormals[i], radius * Math.sin(a));
        positions.push(...q.toArray());
      }
    }
    for (let i = 0; i < 40; i++) for (let j = 0; j < 20; j++) {
      const a = i * 21 + j, b = a + 21;
      // +cos(N), +sin(B) winding: reverse the usual TubeGeometry index order so the cast
      // wall normals face outward (TubeGeometry itself uses -cos(N)).
      indices.push(a, a + 1, b, a + 1, b + 1, b);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setIndex(indices); geo.computeVertexNormals();
    mark(add('runners', geo, M.cast),'runner-intake',cy.i);
    mark(box('runners', [14, 58, 70], [124, DECK + 48, cy.z], M.castLight, 8),'runner-intake',cy.i);
    mark(box('runners', [78, 7, 72], [PX + 3, seamY - 8, cy.z * 0.94], M.cast, 5),'runner-intake',cy.i);
    for (const s of [-1, 1]) mark(bolt('runners', 134, DECK + 68, cy.z + s * 28, 'x', 5),'runner-intake',cy.i);
    // The casting parting line is fine, so it reads at close range without looking like a second pipe.
    mark(tube('runners', [[169, DECK + 8, cy.z + 26], [206, DECK - 51, cy.z + 24], [245, DECK - 31, cy.z * 0.96 + 25]], 0.85, M.castLight, null, 20, 6),'runner-intake',cy.i);
  }
  // Thin EGR-passage cover along the head flange (intake-manifold refs16/17), a support stay and cable bracket.
  box('runners', [25, 5, 374], [147, DECK + 78, -5], M.castLight, 3);
  box('runners', [27, 1.3, 376], [147, DECK + 74.7, -5], M.gasket, 1);
  for (const z of [-175, -88, 1, 90, 174]) bolt('runners', 147, DECK + 83, z, 'y', 4.5);
  const stay = box('runners', [8, 116, 25], [187, DECK - 76, 45], M.darkSteel, 2);
  stay.rotation.z = -0.44;
  for (const p of [[164, DECK - 128, 45], [209, DECK - 25, 45]]) bolt('runners', ...p, 'x', 7);
  mark(tube('fuelRail', [[151, DECK + 106, 166], [151, DECK + 106, -141], [153, DECK + 98, -196]], 2.8, M.brass, null, 24, 8),'rail-fuel');
  for (const z of [-143, 48, 144]) mark(box('fuelRail', [16, 4, 9], [150, DECK + 106, z], M.darkSteel, 1),'rail-fuel');
  for (const cy of CYL) {
    mark(ring('injectors', 7.6, 1.2, [137, DECK + 77, cy.z], [0, 1, 0], M.rubber),'seal-injector',cy.i);
    connector('injectors', [146, DECK + 79, cy.z + 15], [15, 14, 18], M.gasket);
  }

  // ---------------------------------------------------------- throttle casting and inlet duct
  clear('throttleBody');
  clear('intakeDuct');
  annulus('throttleBody', 35, 29, 48, [PX, PY + 6, -284], [0, 0, 1], M.castLight);
  const throttleFlange = new THREE.Shape();
  throttleFlange.moveTo(-43, -40); throttleFlange.lineTo(42, -40); throttleFlange.lineTo(42, 43); throttleFlange.lineTo(-43, 43); throttleFlange.closePath();
  const bore = new THREE.Path(); bore.absarc(0, 0, 29, 0, TAU, true); throttleFlange.holes.push(bore);
  for (const x of [-34, 34]) for (const y of [-31, 34]) {
    const hole = new THREE.Path(); hole.absarc(x, y, 4, 0, TAU, true); throttleFlange.holes.push(hole);
  }
  const fg = new THREE.ExtrudeGeometry(throttleFlange, {depth: 5, bevelEnabled: true, bevelSize: 1.2, bevelThickness: 1.2, bevelSegments: 1});
  at(add('throttleBody', fg, M.cast), PX, PY + 6, -263);
  for (const x of [-34, 34]) for (const y of [-31, 34]) bolt('throttleBody', PX + x, PY + 6 + y, -265, 'z', 5);
  // Butterfly is shown slightly open, as a static explanatory detail; throttle position is not simulated.
  const butterfly = at(add('throttleBody', cylZ(28.3, 1.4, 32), M.brass), PX, PY + 6, -285);
  butterfly.rotation.y = 0.24;
  at(add('throttleBody', cylX(3, 87, 14), M.steel), PX, PY + 6, -285);
  const sector = add('throttleBody', new THREE.TorusGeometry(24, 2.2, 6, 32, Math.PI * 1.25), M.darkSteel);
  sector.position.set(PX + 45, PY + 6, -285); sector.rotation.y = Math.PI / 2;
  at(add('throttleBody', cylX(10, 10, 20), M.darkSteel), PX + 43, PY + 6, -285);
  const springPts = [];
  for (let i = 0; i <= 96; i++) {
    const a = i / 96 * TAU * 5;
    springPts.push([PX + 38 + i / 96 * 12, PY + 6 + 8 * Math.cos(a), -285 + 8 * Math.sin(a)]);
  }
  tube('throttleBody', springPts, 1.1, M.steel, null, 96, 5);
  connector('throttleBody', [PX - 40, PY + 11, -281], [20, 29, 27]);
  box('throttleBody', [43, 8, 45], [PX - 4, PY - 35, -280], M.castLight, 4);
  hollowTube('throttleBody', [[PX + 14, PY - 33, -289], [PX + 31, PY - 50, -289]], 6, 2, M.cast, 8);
  const ductPts = [[PX, PY + 6, -309], [PX - 10, PY + 30, -340], [170, DECK + 112, -356], [90, DECK + 122, -360], [40, DECK + 118, -380], [30, DECK + 114, -410]];
  const dc = hollowTube('intakeDuct', ductPts, 38, 3.5, M.plasticPlain, 64);
  // Photos show short accordion sections and widely spaced moulded hoops, not corrugations over the whole duct.
  for (const u of [0.05, 0.09, 0.13, 0.17, 0.21, 0.25, 0.43, 0.57, 0.69, 0.81, 0.93]) {
    ring('intakeDuct', 39, u < 0.3 ? 2.6 : 1.4, dc.getPointAt(u).toArray(), dc.getTangentAt(u).toArray(), M.plasticPlain);
  }
  for (const u of [0.025, 0.97]) clamp('intakeDuct', dc.getPointAt(u).toArray(), dc.getTangentAt(u).toArray(), 38);
  box('intakeDuct', [145, 34, 60], [110, DECK + 92, -355], M.paintBlack, 13);
  // A moulded resonator seam, top clip and smaller branch mouth are distinctive in photo 8.
  box('intakeDuct', [146, 2, 60], [110, DECK + 96, -355], M.plasticPlain, 1);
  box('intakeDuct', [21, 8, 30], [120, DECK + 162, -351], M.plasticPlain, 2);
  const branch = hollowTube('intakeDuct', [[150, DECK + 40, -320], [140, DECK + 50, -360], [130, DECK + 54, -400]], 24, 3, M.rubber, 24);
  clamp('intakeDuct', branch.getPointAt(0.92).toArray(), branch.getTangentAt(0.92).toArray(), 24);
  hollowTube('intakeDuct', [[145, DECK + 145, -348], [146, DECK + 164, -344]], 6.5, 2, M.plasticPlain, 8);

  // ---------------------------------------------------------- pressed exhaust shield
  clear('heatShield');
  const shieldShape = new THREE.Shape();
  // Shape coordinates are z and y; the sheet is gently dished away from the exhaust runners.
  shieldShape.moveTo(-204, DECK + 75);
  shieldShape.quadraticCurveTo(-217, DECK + 67, -212, DECK + 34);
  shieldShape.lineTo(-194, DECK + 7);
  shieldShape.quadraticCurveTo(-166, DECK - 8, -139, DECK - 23);
  shieldShape.quadraticCurveTo(-116, DECK - 47, -111, 91);
  shieldShape.quadraticCurveTo(-101, 63, -68, 60);
  shieldShape.lineTo(16, 60);
  shieldShape.quadraticCurveTo(54, 63, 57, 94);
  shieldShape.quadraticCurveTo(62, 151, 85, DECK - 24);
  shieldShape.quadraticCurveTo(111, DECK - 10, 134, DECK + 10);
  shieldShape.quadraticCurveTo(151, DECK + 32, 144, DECK + 60);
  shieldShape.quadraticCurveTo(140, DECK + 75, 124, DECK + 78);
  shieldShape.lineTo(-188, DECK + 78); shieldShape.closePath();
  const inspectionHoles = [[-119, DECK + 43], [51, DECK + 43]];
  for (const [z, y] of inspectionHoles) {
    const hole = new THREE.Path(); hole.absarc(z, y, 6.8, 0, TAU, true); shieldShape.holes.push(hole);
  }
  const shieldX = (z, y) => {
    const t = THREE.MathUtils.clamp((DECK + 78 - y) / 240, 0, 1);
    return -145 - 68 * Math.sin(Math.min(1, t * 1.6) * Math.PI / 2) - 9 * Math.max(0, 1 - ((z + 32) / 178) ** 2);
  };
  const sg = new THREE.ShapeGeometry(shieldShape, 16).toNonIndexed();
  const source = sg.getAttribute('position'), sheet = [], uvs = [], sheetNormals = [];
  const emitTriangle = (a, b, c, level) => {
    if (level) {
      const ab = a.clone().add(b).multiplyScalar(0.5), bc = b.clone().add(c).multiplyScalar(0.5), ca = c.clone().add(a).multiplyScalar(0.5);
      emitTriangle(a, ab, ca, level - 1); emitTriangle(ab, b, bc, level - 1);
      emitTriangle(ca, bc, c, level - 1); emitTriangle(ab, bc, ca, level - 1); return;
    }
    for (const p of [a, b, c]) {
      sheet.push(shieldX(p.x, p.y), p.y, p.x);
      uvs.push((p.x + 220) / 380, (p.y - 60) / 240);
      const dy = (shieldX(p.x, p.y + 0.1) - shieldX(p.x, p.y - 0.1)) / 0.2;
      const dz = (shieldX(p.x + 0.1, p.y) - shieldX(p.x - 0.1, p.y)) / 0.2;
      sheetNormals.push(...V(-1, dy, dz).normalize().toArray());
    }
  };
  for (let i = 0; i < source.count; i += 3) emitTriangle(new THREE.Vector3().fromBufferAttribute(source, i), new THREE.Vector3().fromBufferAttribute(source, i + 1), new THREE.Vector3().fromBufferAttribute(source, i + 2), 2);
  sg.dispose();
  const sheetGeo = new THREE.BufferGeometry();
  sheetGeo.setAttribute('position', new THREE.Float32BufferAttribute(sheet, 3));
  sheetGeo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  sheetGeo.setAttribute('normal', new THREE.Float32BufferAttribute(sheetNormals, 3));
  add('heatShield', sheetGeo, M.shield);
  const edge = shieldShape.getPoints(60).map(p => [shieldX(p.x, p.y) - 0.5, p.y, p.x]);
  tube('heatShield', edge, 1.7, M.shield, null, 100, 6);
  for (const [z, y] of inspectionHoles) ring('heatShield', 7.2, 0.8, [shieldX(z, y) - 0.6, y, z], [1, 0, 0], M.darkSteel);
  for (const [z, y] of [[-172, DECK + 13], [112, DECK + 13], [35, 88]]) {
    const x = shieldX(z, y) - 3;
    washer('heatShield', [x, y, z], [1, 0, 0], 10); bolt('heatShield', x - 3, y, z, 'x', 7.5, M.rust);
  }
  // Pressed stiffening bead around the lower collector, and the embossed warning panel outline.
  tube('heatShield', [[shieldX(-108, 115) - 2, 115, -108], [-224, 108, -70], [-224, 108, -20], [shieldX(48, 117) - 2, 117, 48]], 2, M.shield, null, 32, 6);
  const stamp = [[-65, DECK + 68], [-65, DECK + 27], [-10, DECK + 27], [-10, DECK + 68], [-65, DECK + 68]].map(([z, y]) => [shieldX(z, y) - 1.2, y, z]);
  tube('heatShield', stamp, 1, M.shield, null, 24, 6);
  // Ports and studs on the iron casting are visible once the shield is removed.
  for (const cy of CYL) for (const s of [-1, 1]) {
    at(add('exhaustManifold', cylX(10, 18, 16), M.iron), -131, DECK + 64, cy.z + s * 27);
    washer('exhaustManifold', [-142, DECK + 64, cy.z + s * 27]);
    bolt('exhaustManifold', -147, DECK + 64, cy.z + s * 27, 'x', 6, M.rust);
  }
  at(add('exhaustManifold', cylX(9, 15, 6), M.rust), -184, DECK - 58, 72);
  box('exhaustManifold', [7, 74, 24], [-144, 72, -30], M.darkSteel, 3);
  for (const y of [41, 103]) bolt('exhaustManifold', -150, y, -30, 'x', 7, M.rust);

  // ---------------------------------------------------------- open hose stubs / fittings
  // Photo 7 shows a genuinely open coolant hose, a split spring clamp, and an angled cast elbow.
  clear('coolantOutlet');
  box('coolantOutlet', [40, 50, 44], [-131, DECK + 46, -226], M.castLight, 8);
  for (const z of [-243, -209]) bolt('coolantOutlet', -153, DECK + 47, z, 'x', 5.5);
  const outlet = hollowTube('coolantOutlet', [[-145, DECK + 44, -226], [-173, DECK + 38, -240], [-205, DECK + 30, -252]], 17, 3.4, M.rubber, 24);
  clamp('coolantOutlet', outlet.getPointAt(0.47).toArray(), outlet.getTangentAt(0.47).toArray(), 17);
  for (const [pos, normal] of [[[80, DECK + 120, 236], [0.4, -1, 0.3]], [[150, 80, 262], [0.05, -1, 0.05]], [[160, -78, 270], [0.1, -1, -0.1]]]) {
    annulus('psHose', 11.5, 10, 22, pos, normal, M.steel);
    for (const dy of [-6, 0, 6]) ring('psHose', 11.6, 0.6, [pos[0], pos[1] + dy, pos[2]], normal, M.darkSteel);
  }

  // ---------------------------------------------------------- alternator ventilated case
  // Replace the static case only. The separate altPulley mesh and the simulated shaft remain intact.
  const alt = G.alternator.children.find(child => child.isGroup && Math.abs(child.position.x - L.alt[0]) < 1);
  if (alt) {
    for (const child of [...alt.children]) { alt.remove(child); child.geometry?.dispose(); }
    const localRing = (radius, width, z, mat = M.castLight) => annulus('alternator', radius, radius - 5, width, [0, 0, z], [0, 0, 1], mat, alt);
    // Stator iron and copper lie inside the open cage; they are visible between the cast bridges.
    add('alternator', cylZ(45, 60, 32), M.darkSteel, alt).position.z = 3;
    for (let k = 0; k < 12; k++) {
      const a = k / 12 * TAU;
      const winding = box('alternator', [9, 12, 42], [Math.cos(a) * 46, Math.sin(a) * 46, 5], M.copper, 3, alt);
      winding.rotation.z = a;
    }
    for (const [z, width, radius] of [[-37, 8, 56], [-15, 6, 58], [12, 6, 58], [39, 7, 59]]) localRing(radius, width, z);
    for (let k = 0; k < 20; k++) {
      const a = k / 20 * TAU;
      const rib = box('alternator', [6, 8, 77], [Math.cos(a) * 55, Math.sin(a) * 55, 1], M.castLight, 1.5, alt);
      rib.rotation.z = a;
      const face = box('alternator', [34, 5, 6], [Math.cos(a) * 39, Math.sin(a) * 39, 44], M.castLight, 1, alt);
      face.rotation.z = a;
    }
    annulus('alternator', 24, 10, 11, [0, 0, 44], [0, 0, 1], M.castLight, alt);
    add('alternator', cylZ(52, 8, 32), M.castLight, alt).position.z = -42;
    box('alternator', [25, 69, 21], [40, -58, 0], M.cast, 5, alt);
    annulus('alternator', 13, 6.5, 22, [40, -84, 0], [0, 0, 1], M.castLight, alt);
    add('alternator', cylZ(19, 25, 20), M.paintBlack, alt).position.set(-29, 26, -55);
    box('alternator', [27, 19, 20], [21, 22, -55], M.paintBlack, 4, alt);
    for (const a of [0.45, 2.55, 4.55]) {
      add('alternator', cylZ(3, 91, 10), M.darkSteel, alt).position.set(Math.cos(a) * 51, Math.sin(a) * 51, 0);
      add('alternator', cylZ(5, 4, 6), M.steel, alt).position.set(Math.cos(a) * 51, Math.sin(a) * 51, 47);
    }
  }

  // ---------------------------------------------------------- steering pump and distributor
  // The base model's solid lathed pulley hid all six holes. Keep the rotating group and its
  // perforated disc, replacing only the thick solid rim by a genuinely annular grooved rim.
  const psPulley = G.psPump.children.find(child => child.isGroup && Math.abs(child.position.z - L.accZ[1]) < 1);
  if (psPulley) {
    for (const child of [...psPulley.children]) if (child.geometry?.type === 'LatheGeometry') { psPulley.remove(child); child.geometry.dispose(); }
    for (const z of [-7, -3, 1, 5]) annulus('psPump', 52, 46, 2.8, [0, 0, z], [0, 0, 1], M.pulleyBright, psPulley);
    annulus('psPump', 49, 46, 16, [0, 0, 0], [0, 0, 1], M.pulley, psPulley);
  }
  const [sx, sy, sz] = L.psp;
  ring('psPump', 39.5, 1.3, [sx, sy, sz - 29], [0, 0, 1], M.darkSteel);
  for (const a of [0.3, 2.4, 4.5]) bolt('psPump', sx + Math.cos(a) * 31, sy + Math.sin(a) * 31, sz - 34, 'z', 5.5);
  box('psPump', [48, 8, 34], [sx + 2, sy + 37, sz - 5], M.castLight, 3);
  for (const dz of [-16, 7]) bolt('psPump', sx + 2, sy + 44, sz + dz, 'y', 5);
  hollowTube('psPump', [[sx - 24, sy + 3, sz - 8], [sx - 43, sy - 15, sz - 8]], 8, 2.5, M.castLight, 8);

  // Four plug-lead towers are visible on the supplied engine. The cap seam and mounting ears
  // follow the Hitachi diagram; exact distributor variant remains subject to the engine stamp.
  const dz = L.headZ[0];
  for (const child of [...G.distributor.children]) if (child.isMesh) { G.distributor.remove(child); child.geometry.dispose(); }
  mark(at(add('distributor', cylZ(31, 40, 32), M.castLight), 0, L.camY, dz - 20),'housing-distributor');
  mark(at(add('distributor', cylZ(39, 36, 32), M.paintBlack), 0, L.camY, dz - 57),'cap-distributor');
  mark(ring('distributor', 39.4, 1.4, [0, L.camY, dz - 39], [0, 0, 1], M.gasket),'cap-distributor');
  const terminalAngles = [0.45, 1.95, 3.5, 5.0];
  for (const a of terminalAngles) {
    const x = Math.cos(a) * 25, y = L.camY + Math.sin(a) * 25;
    mark(annulus('distributor', 8, 5.5, 20, [x, y, dz - 81], [0, 0, 1], M.paintBlack),'cap-distributor');
    mark(ring('distributor', 8.1, 1, [x, y, dz - 87], [0, 0, 1], M.rubber),'cap-distributor');
  }
  for (const a of [0, Math.PI]) {
    const x = Math.cos(a) * 42;
    mark(box('distributor', [17, 21, 12], [x, L.camY, dz - 38], M.castLight, 4),'housing-distributor');
    mark(bolt('distributor', x, L.camY, dz - 46, 'z', 4.5),'housing-distributor');
  }
  connector('distributor', [27, L.camY + 29, dz - 20], [21, 24, 23], M.gasket);
  clear('plugLeads');
  CYL.forEach((cy, k) => {
    const a = terminalAngles[k], x = Math.cos(a) * 25, y = L.camY + Math.sin(a) * 25;
    mark(tube('plugLeads', [[x, y, dz - 92], [x - 26, L.coverY[1] + 22 + k * 4, dz - 91], [-88 - k * 4, L.coverY[1] + 17 + k * 3, dz + 20], [-90, L.coverY[1] + 24, cy.z - 28], [-66, L.coverY[1] + 25, cy.z]], 3.6, M.rubber, null, 52, 8),'lead-spark-plug',cy.i);
    mark(at(add('plugLeads', cylZ(9, 22, 16), M.rubber), x, y, dz - 89),'lead-spark-plug',cy.i);
    // The lead must terminate in the rubber boot seated in the cover well.
    mark(at(add('plugLeads', new THREE.CylinderGeometry(14, 12, 30, 24), M.rubber), -66, L.coverY[1] + 10, cy.z),'lead-spark-plug',cy.i);
    mark(ring('plugLeads', 13.5, 1.5, [-66, L.coverY[1] + 22, cy.z], [0, 1, 0], M.rubber),'lead-spark-plug',cy.i);
  });
  for (const z of [-105, 88]) {
    box('plugLeads', [32, 6, 8], [-91, L.coverY[1] + 23, z], M.plasticPlain, 2);
  }
}
