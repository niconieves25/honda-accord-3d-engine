# Honda F22 Engine Explorer

An interactive 3D explainer of the 1994–97 Honda Accord 2.2-litre SOHC VTEC engine. It was built for a viewer with glaucoma, to help recognise the outside parts, see where they connect, and explore how the inside works.

## Open it

Double-click **`index.html`**, or from the project folder run:

```sh
open "engine-explorer/index.html"
```

It is one offline file and needs no internet or install. Chrome, Safari, Edge and Firefox all work. It keeps the reference library in place: the "Honda diagram" links open the OEM drawings from `../Honda Reference Library/02_OEM_Diagrams/`.

## Using it

- **Views** (keys `1`–`7`): the navigation above the engine offers Outside (photo 1's angle), Valve cover off, Timing covers off, One cylinder cut open, Crankshaft and bottom, VTEC close-up, Taken apart.
- **Turn and zoom:** drag, or focus the engine and use the arrow keys (Shift for bigger steps); scroll or `+`/`−` to zoom; `R` resets the view.
- **Inspector:** the **Parts**, **Details** and **Motion** tabs show one group of information at a time. Use the left/right arrow keys, Home or End while a tab has focus to change tabs.
- **Parts and Details:** click a part on the engine, search in Parts (`/` opens the search), or step through with `N`/`P`. Selection opens Details, which explains where the part is, what it does, what it connects to and how it moves, with its Honda diagram callout. A ≈ mark means the shape or position is approximate.
- **One system at a time:** "Show one system" in Parts fades everything else but keeps it faintly visible for orientation.
- **Playback:** the compact footer keeps Play/Pause (`Space`), step back and forward (`,` `.`), speed and crankshaft angle available. Four speeds range from one crank turn in 16 s to one per second.
- **Motion:** open the Motion tab or its footer shortcut for the four cylinder status cards, crankshaft and cycle angles, and the step-size selector (5–180°). Each cylinder's stroke uses a word and a shape, not colour alone.
- **VTEC** (`V`): the Motion tab contains this educational switch. Each cylinder changes over only while its intake valves are closed, as on the real engine.
- **Flow paths:** the Motion tab also contains air and fuel, exhaust, oil and coolant controls. Each flow has its own marker shape, and all are labelled schematic.
- **Display:** text size 100–240 %, label size, three colour schemes (high-contrast dark, high-contrast light, soft), labels on the engine (key parts, selected only, or none), reduce motion, and spoken part names. "Read aloud" in the details panel reads the whole description. Settings are remembered on this computer.

## Anatomy: individual components

Open **`anatomy.html`** for the Spanish component atlas, or use the component-atlas navigation from the assembled engine. This is a second page developed with the installed [Anatomy](https://github.com/wheresryan22/anatomy) skill. The viewer uses the same Three.js studio and physically lit surfaces as the complete engine. Existing components are isolated from the engine geometry; supplementary Anatomy mechanisms are converted into solid Three.js meshes. It shows one component at a time, with 3D inspection, a slow operating demonstration, an explanation and an MP4 video.

The atlas contains **92 component types across 12 systems**. Of these, 67 reuse meshes and materials from the assembled engine; 25 use supplementary Anatomy geometry with the same studio finish. A type is not the same as an installed instance: one piston entry describes four pistons, whereas the two exhaust-rocker types have separate entries. Bearing colour grades, piston size classes, replacement numbers and supplier alternatives are not extra pieces fitted simultaneously. The original engine page still provides the 59 larger selectable groups for orientation.

Each record gives the Spanish and English names, installed quantity or quantity limitation, location, function, connections, motion and its driver, three explanatory steps, and OEM diagram/callout references. A subcomponent such as a VTEC synchronizing piston is explicitly distinguished from the complete assembly that owns its catalogue number.

- **Inspecting and operating are different:** a stationary cover, gasket, guide or sensor remains mechanically stationary. Its inspection video changes the viewing angle. A pump has a fixed housing and moving internal parts. Captions identify these distinctions.
- **Videos:** the `anatomy-media/` folder contains real H.264 MP4 files with Spanish captions, matching WebVTT captions and poster images. They are caption-only videos, with **no embedded audio**. Keep this folder beside `anatomy.html` when copying the atlas.
- **Read aloud:** page narration uses the browser's native `SpeechSynthesis` and an available Spanish system voice. Voice availability and pronunciation depend on the browser and operating system. It does not add an audio track to the MP4 files.
- **Evidence:** OEM identifiers are checked against the saved JSON catalogue in the reference library. Exploded diagrams establish identity and assembly relationships, not full manufacturing geometry.

The engine identification remains **provisional F22B1 / 1994 US Accord EX** until its stamped code and market are confirmed. Isolated figures are educational reconstructions: most external dimensions, small profiles, material finishes, fluid passages and actuator travel are approximate. The 85 mm bore and 95 mm piston stroke are reference values; the assumed connecting-rod length and demonstration cam profiles do not become factory measurements in the atlas. Control-valve clips illustrate a change of state; they are not ECU calibrations or measured pressure/temperature simulations.

From the project folder:

```sh
node engine-explorer/scripts/build-anatomy.mjs
node engine-explorer/tests/anatomy.mjs
node engine-explorer/tests/anatomy-pbr.mjs
node engine-explorer/scripts/export-anatomy-pbr.mjs
```

Video production uses the same `mountPbrFigure` renderer as the page. The local export page sends its own rendered frames to a loopback receiver, which encodes H.264 MP4s with local `ffmpeg`; `ffprobe` verifies the result. Open the URL printed by `export-anatomy-pbr.mjs` and use its visible controls to render the collection. The previous SVG renderer remains available for diagram development, but it is not the production appearance of the atlas. CPU checks validate catalogue evidence, parent-group links, mesh bounds and motion contracts; they do not replace visual review or prove manufacturing clearances.

```
anatomy.html                     built Spanish atlas page
anatomy-app/                     atlas entry point and accessible layout styles
src/anatomy/catalog.js           92 component types, descriptions and OEM evidence
src/anatomy/figures.mjs          component-specific Anatomy 3D figures and SVG renderer
src/anatomy/motion.mjs           shared operating poses for the page and videos
src/studio.js                   shared lighting, reflections and colour settings
src/anatomy/pbr-runtime.js       catalogue studio, camera fitting and inspection
src/anatomy/engine-parts.js      individual components isolated from the engine
src/anatomy/three-adapter.js     Anatomy supplementary geometry as PBR meshes
src/anatomy/figure-runtime.js    retained SVG diagram renderer
src/anatomy/ui.js                atlas navigation, reading, playback and media controls
src/anatomy/vendor/              vendored Anatomy kit and MIT license
anatomy-media/                   MP4s, posters, WebVTT files and manifest.json
tests/anatomy.mjs                CPU catalogue, evidence, geometry and motion checks
```

## Rebuilding and checking

The page is built with the [teardown](https://github.com/elvarofficial/teardown) skill's bundler (three.js, fonts and styles inlined):

```sh
engine-explorer/scripts/build.sh     # → engine-explorer/index.html, then runs the timing checks
node engine-explorer/tests/timing.mjs   # 20 checks: firing order, piston pairs, rotation, ratios, VTEC switching
node engine-explorer/tests/geometry.mjs # CPU checks: open bores, pin axes, finite meshes, sampled valve/piston clearance
node engine-explorer/tests/ui.mjs       # drives the page: every view, picking, keyboard, focus ring, text size, VTEC
node engine-explorer/tests/compare.mjs  # renders each photo's viewpoint beside the photo (.build/compare)
```

On macOS the tests launch headless Chromium with the Metal backend so WebGL works.

## Layout

```
src/kin.js        the math: one crank angle drives everything; SPEC and ASSUMED values kept apart
src/engine.js     the geometry, built from code after the photos and the OEM diagrams
src/detail-*.js   casting, exterior and internal refinements tied to the saved OEM references
src/consolidate-static.js  combines fixed details within each part to reduce draw calls
src/parts.js      every selectable part, its system and its OEM diagram callouts
src/i18n/en.js    every word shown or spoken, ready to copy for a translation
src/flows.js      the schematic flow paths
src/stage.js      lights, camera, orbit, outline, picking, cutaway
src/views.js      the seven views
src/app.js        the accessible interface
app/              build entry and stylesheet
tests/            timing, interface and photo-comparison checks
```

## What is approximate

The reference engine figures are 85 × 95 mm, 2,156 cc and 8.8:1. Bore and piston travel follow those dimensions; the illustrated chamber has not been calibrated to the published compression ratio. Cylinder 1 is at the timing-belt end and the firing order is 1-3-4-2. The crank turns counter-clockwise from the pulley end, the cam runs at half speed, and the balance shafts run at twice speed, counter-rotating. These are approximate:

- **Engine identity:** the stamped engine code is unconfirmed. F22B1 (1994 US Accord EX) is the provisional reference.
- **Internal dimensions:** rod length (142 mm), piston pin height and cylinder spacing (96 mm) are assumed.
- **Valvetrain:** valve angles, valve-seat height (11 mm above the deck), valve lift and cam lobe shapes are teaching geometry. The seat height preserves clearance in this model; it is not a factory measurement. The VTEC switching rule is real, but the lift curves are illustrative.
- **Outside shapes:** sizes are estimated from the photographs. Casting ribs, rear seal carrier, cover contours, intake flanges, wiring, connectors and fasteners follow the references visually; their precise dimensions remain unverified.
- **Fine internal geometry:** piston dishes, reliefs, skirt profiles, rod sections, oil-ring expander, bearing holders, chamber roofs and port paths follow the assembly diagrams qualitatively. They are not manufacturing CAD.
- **Hidden part positions:** the balance shafts and their drive, the oil-pump gear case, the water pump, the tensioner and the thermostat are placed approximately.
- **Pulley speeds:** accessory pulley sizes, and so their speeds, are estimated. Tooth profiles and rendered tooth counts are illustrative.
- **Flow paths:** oil and coolant lines show the route in general, not the real drillings. No live pressures are simulated.

## Reference detail pass

The refinement uses the saved `cylinder_block_oil_pan`, `cylinder_head`, `cylinder_head_cover` (right-hand VTEC variant), `camshaft_timing_belt`, `crankshaft_piston`, `valve_rocker_arm`, `oil_pump_oil_strainer`, intake, exhaust, ignition and accessory diagrams alongside photos 1–9. The block and gasket now have open bores; the crankcase, main bridge and cam holders have clearance openings. Pistons have recessed crowns, open skirts and separate ring packs; pins run parallel to the crank. The exterior includes formed covers, open pulley windows, hollow duct mouths, vented alternator housing, clamps, seams, connectors and the four plug boots. Timing and balancer drives have transverse sprocket teeth and moving belt teeth; their counts, profiles, wrap routes and meshing remain illustrative. Stationary details are combined per selectable part; all motion still uses the original crank angle.
